use revm::{
    db::{CacheDB, EmptyDB},
    primitives::{address, hex, AccountInfo, Bytecode, TransactTo, U256}, Database,
};
use revmc_examples_counter::build_evm;

include!("./common.rs");

fn main() {
    let db = CacheDB::new(EmptyDB::new());
    let mut evm = build_evm(db);
    let counter_address = address!("0000000000000000000000000000000000001234");
    evm.db_mut().insert_account_info(
        counter_address,
        AccountInfo {
            code_hash: COUNTER_HASH.into(),
            code: Some(Bytecode::new_raw(COUNTER_CODE.into())),
            ..Default::default()
        },
    );
    evm.context.evm.env.tx.transact_to = TransactTo::Call(counter_address);
    let result = evm.transact_commit().unwrap();
    eprintln!("{:#?}", result);

    let number = evm.db_mut().storage(counter_address, U256::ZERO).unwrap();
    println!("number() = {}", number);
}
